# frozen_string_literal: true

module IPinfoRails
    VERSION = '1.0.1'
end
